#include "queue.h"

int main () {
    srand(time(NULL));
    int i, n = 10;
    int num;

    Queue *pares = create(n);
    Queue *impares = create(n);

    for(i=0; i<n; i++)
    {
    num = rand()%100;
    if(num%2)
        enqueue(impares, num);
    else
        enqueue(pares, num);
    }

    print(pares);
    print(impares);

    destroy(pares);
    destroy(impares);

    return 0;
}
