#include "queue.h"
#include <time.h>

void jackpot (int n, int r) {
    int i, giros, ganhou=0;

    Queue *c1 = create(r+1);
    Queue *c2 = create(r+1);
    Queue *c3 = create(r+1);

    for(i=0; i<r; i++)
    {
        enqueue(c1, i);
        enqueue(c2, i);
        enqueue(c3, i);
    }

    while(!ganhou)
    {
        giros = rand()%10;
        for(i=0; i<giros; i++)
        {
            int elem = dequeue(c1);
            enqueue(c1, elem);
        }

        giros = rand()%10;
        for(i=0; i<giros; i++)
        {
            int elem = dequeue(c2);
            enqueue(c2, elem);
        }

        giros = rand()%10;
        for(i=0; i<giros; i++)
        {
            int elem = dequeue(c3);
            enqueue(c3, elem);
        }

        if (front(c1)==front(c2) && front(c1)==front(c3))
            ganhou = 1;
        printf("%d | %d | %d\n", front(c1), front(c2), front(c3));
    }
    printf("\nvoce venceu!!!\n");

    destroy(c1);
    destroy(c2);
    destroy(c3);
}

int main () {
    srand(time(NULL));
    int n = 3;  /*número de carretéis*/
    int r = 10; /*sequência de números em cada carretel*/
    jackpot (n, r);

    return 0;
}
